module.exports = {
    'mongoURL':'mongodb://localhost:27017',
    'db':'BlogServer',
    'secret_key':'C-UFRaksvPKhx1txJYFcut3QGxsafPmwCY6SCly3G6c'
};
